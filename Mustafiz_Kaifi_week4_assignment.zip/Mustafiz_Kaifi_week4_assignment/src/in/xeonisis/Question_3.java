package in.xeonisis;


//Implement a program that handles multiple
//        exceptions (e.g., ArithmeticException,
//        NullPointerException) and uses custom
//        exceptions

import java.util.Scanner;

// Custom Exception
class InvalidAgeException extends Exception {
    public InvalidAgeException(String message) {
        super(message);
    }
}

public class Question_3 {

    // Method to demonstrate handling ArithmeticException
    public static void divideNumbers(int a, int b) {
        try {
            int result = a / b;
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Error: Cannot divide by zero!");
        }
    }

    // Method to demonstrate handling NullPointerException
    public static void printStringLength(String str) {
        try {
            System.out.println("String length: " + str.length());
        } catch (NullPointerException e) {
            System.out.println("Error: String is null!");
        }
    }

    // Method that throws custom exception for invalid age
    public static void checkAge(int age) throws InvalidAgeException {
        if (age < 0 || age > 120) {
            throw new InvalidAgeException("Age must be between 0 and 120.");
        } else {
            System.out.println("Valid age: " + age);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Handling ArithmeticException
        System.out.println("Handling ArithmeticException:");
        System.out.print("Enter first number: ");
        int num1 = scanner.nextInt();
        System.out.print("Enter second number: ");
        int num2 = scanner.nextInt();
        divideNumbers(num1, num2);

        // Handling NullPointerException
        System.out.println("\nHandling NullPointerException:");
        System.out.print("Enter a string (or type 'null' to simulate null string): ");
        String input = scanner.next();
        String str = input.equals("null") ? null : input;
        printStringLength(str);

        // Handling Custom Exception
        System.out.println("\nHandling Custom Exception (InvalidAgeException):");
        System.out.print("Enter your age: ");
        int age = scanner.nextInt();
        try {
            checkAge(age);
        } catch (InvalidAgeException e) {
            System.out.println("Error: " + e.getMessage());
        }

        scanner.close();
    }
}

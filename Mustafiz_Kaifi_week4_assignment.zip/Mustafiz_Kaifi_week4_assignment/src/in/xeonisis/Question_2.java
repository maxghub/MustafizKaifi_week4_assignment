package in.xeonisis;


//Create a program that uses a HashMap to store
//        and retrieve employee details based on their
//        employee ID

import java.util.HashMap;
import java.util.Scanner;

class Employee {
    private String name;
    private String department;
    private double salary;

    public Employee(String name, String department, double salary) {
        this.name = name;
        this.department = department;
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Name: " + name + ", Department: " + department + ", Salary: " + salary;
    }
}

public class Question_2 {
    private HashMap<Integer, Employee> employeeMap;

    public Question_2() {
        employeeMap = new HashMap<>();
    }

    // Method to add an employee
    public void addEmployee(int id, String name, String department, double salary) {
        Employee employee = new Employee(name, department, salary);
        employeeMap.put(id, employee);
        System.out.println("Employee added successfully.");
    }

    // Method to retrieve employee details by ID
    public void getEmployee(int id) {
        Employee employee = employeeMap.get(id);
        if (employee != null) {
            System.out.println("Employee Details: " + employee);
        } else {
            System.out.println("Employee with ID " + id + " not found.");
        }
    }

    // Method to display all employees
    public void displayAllEmployees() {
        if (employeeMap.isEmpty()) {
            System.out.println("No employees to display.");
        } else {
            System.out.println("List of all employees:");
            for (Integer id : employeeMap.keySet()) {
                System.out.println("ID: " + id + ", " + employeeMap.get(id));
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Question_2 manager = new Question_2();

        while (true) {
            System.out.println("\n1. Add Employee");
            System.out.println("2. Get Employee Details");
            System.out.println("3. Display All Employees");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter employee ID: ");
                    int id = scanner.nextInt();
                    System.out.print("Enter employee name: ");
                    String name = scanner.next();
                    System.out.print("Enter employee department: ");
                    String department = scanner.next();
                    System.out.print("Enter employee salary: ");
                    double salary = scanner.nextDouble();
                    manager.addEmployee(id, name, department, salary);
                    break;
                case 2:
                    System.out.print("Enter employee ID to retrieve: ");
                    int searchId = scanner.nextInt();
                    manager.getEmployee(searchId);
                    break;
                case 3:
                    manager.displayAllEmployees();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }
}
